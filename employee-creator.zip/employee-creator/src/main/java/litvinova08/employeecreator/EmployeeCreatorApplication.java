package litvinova08.employeecreator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCreatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCreatorApplication.class, args);
	}

}
